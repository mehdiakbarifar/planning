import { initHeaderClock, initThemeSwitcher, initFontSizeAdjuster, restoreScrollPositions, initAutoScroll } from './uiUtils.js';
import { setupCSVLoading } from './csvHandler.js';
import { initCharts } from './chartHandler.js';
import { populateTables } from './tableData.js';

document.addEventListener('DOMContentLoaded', () => {
  // Initialize clock, theme switcher, auto-scroll, and accessibility features
  initHeaderClock();
  initThemeSwitcher();
  restoreScrollPositions();
  initAutoScroll();
  initFontSizeAdjuster();

  // Populate tables and load charts after CSV processing
  populateTables();
  setupCSVLoading();
  initCharts();

  // Initialize desktop-specific features
  initDragResize();
  initSectionFilters();

  // Adapt UI for different viewports and handle tab navigation
  adaptToViewport();
  initTabNavigation();
});

// ---- Adapt Desktop vs Mobile View ---- //
function adaptToViewport() {
  const isMobile = window.innerWidth < 768;
  document.querySelector('.dashboard-grid').style.display = isMobile ? 'block' : 'grid';
  document.querySelector('.tab-nav').style.display = isMobile ? 'flex' : 'none';

  // Hide drag bars in mobile view to prevent layout conflicts
  document.getElementById('drag-vertical').style.display = isMobile ? 'none' : 'block';
  document.getElementById('drag-horizontal').style.display = isMobile ? 'none' : 'block';

  // Ensure chart containers are properly visible on mobile
  document.querySelectorAll("canvas").forEach(canvas => {
    canvas.style.minHeight = "200px";
    canvas.style.display = "block";
  });

  console.log("Viewport adapted:", isMobile ? "Mobile mode enabled" : "Desktop mode enabled");
}
window.addEventListener('resize', adaptToViewport);

// ---- Initialize Mobile Tab Navigation ---- //
function initTabNavigation() {
  const tabButtons = document.querySelectorAll('.tab-button');
  const sections = document.querySelectorAll('.section');

  // Force default tab to section-a for testing
  const defaultTab = 'section-a';

  // Ensure only one active section is shown
  sections.forEach(section => section.classList.remove('active'));
  document.getElementById(defaultTab)?.classList.add('active');

  tabButtons.forEach(btn => btn.classList.remove('active'));
  document.querySelector(`.tab-button[data-target="${defaultTab}"]`)?.classList.add('active');

  console.log("Default active tab set to:", defaultTab);

  // Set up click listeners for tab buttons
  tabButtons.forEach(button => {
    button.addEventListener('click', function () {
      console.log("Tab clicked:", this.getAttribute('data-target'));

      // Remove active class from all tabs and sections
      tabButtons.forEach(btn => btn.classList.remove('active'));
      sections.forEach(section => section.classList.remove('active'));

      // Activate the clicked tab and corresponding section
      this.classList.add('active');
      const target = this.getAttribute('data-target');
      const targetSection = document.getElementById(target);
      if (targetSection) {
        targetSection.classList.add('active');
        console.log("Activated section:", target);
      } else {
        console.error("Section not found:", target);
      }
    });
  });
}

// ---- Desktop Drag Resize Functionality ---- //
function initDragResize() {
  // Disable drag-resize on mobile
  if (window.innerWidth < 768) return;

  const container = document.querySelector('.dashboard-grid');
  const verticalBar = document.getElementById('drag-vertical');
  const horizontalBar = document.getElementById('drag-horizontal');

  // Restore saved grid dimensions if available
  const savedCols = localStorage.getItem('gridColumns');
  const savedRows = localStorage.getItem('gridRows');
  if (savedCols) container.style.gridTemplateColumns = savedCols;
  if (savedRows) container.style.gridTemplateRows = savedRows;

  // Ensure charts are visible after resize
  function updateTableSizes() {
    document.querySelectorAll('.scrollable-table').forEach(cont => {
      cont.style.maxHeight = cont.parentElement.clientHeight + "px";
    });
  }
  window.addEventListener('resize', updateTableSizes);

  // Update drag bar positions
  function updateDragBarPositions() {
    const rect = container.getBoundingClientRect();
    const colTemplate = getComputedStyle(container).gridTemplateColumns.split(" ");
    let col1Width = parseFloat(colTemplate[0]);
    if (colTemplate[0].endsWith('%')) {
      col1Width = rect.width * (parseFloat(colTemplate[0]) / 100);
    }
    verticalBar.style.left = (col1Width - 2.5) + 'px';

    const rowTemplate = getComputedStyle(container).gridTemplateRows.split(" ");
    let row1Height = parseFloat(rowTemplate[0]);
    if (rowTemplate[0].endsWith('%')) {
      row1Height = rect.height * (parseFloat(rowTemplate[0]) / 100);
    }
    horizontalBar.style.top = (row1Height - 2.5) + 'px';
  }
  updateDragBarPositions();
  window.addEventListener('resize', updateDragBarPositions);
}

// ---- Initialize Section Filters for Table Search Inputs ---- //
function initSectionFilters() {
  const filters = document.querySelectorAll('.section-filter');
  filters.forEach(filter => {
    filter.addEventListener('keyup', (event) => {
      const query = event.target.value.toLowerCase();
      const targetSelector = event.target.getAttribute('data-target');
      if (!targetSelector) return;
      const table = document.querySelector(targetSelector);
      if (!table) return;
      table.querySelectorAll("tbody tr").forEach(row => {
        row.style.display = row.innerText.toLowerCase().includes(query) ? "" : "none";
      });
    });
  });
}

// ---- Force Chart Refresh on Mobile Resize ---- //
window.addEventListener("resize", function () {
  console.log("Viewport resized, attempting chart refresh...");
  initCharts();
});
